package api.bdd_style;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;

public class ViewAPI {

	@Test
	public void getAllHouseholds() {
		int houseHoldPRID = RestAssured
			.given()
				.baseUri("http://3.111.228.79:3000/prayojana")
				.header("content.type", "application/json")
		 	.when()
				.get("/household")
			.then()
				.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/"+"householdDetailsSchema.json"))
				.assertThat().statusCode(200)
				.extract().jsonPath().getInt("message[0].pridNo");
		System.out.println("Household PR ID: "+houseHoldPRID);
	}
	
	

}
