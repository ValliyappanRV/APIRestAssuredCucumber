package api.json_schema_validation;

public class RestAssuredJsonSchemaValidation {
	
	public void validationUsingJsonSchemaInClassPath() {
		
	}

}
